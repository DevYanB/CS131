fun <T> everyNth(lst: List<T>, n: Int): List<T> {
   if (n < 1 || n > lst.size) return emptyList()
   var index = n-1
   val tmp_list = ArrayList<T>()
   while (index < lst.size) {
   	 tmp_list.add(lst.get(index))
	 index += n
   }
   return tmp_list
}


fun main(args : Array<String>){
    val a_test = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
    val b_test = listOf("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l")
    
    val a_res = everyNth(a_test,3)
    val b_res = everyNth(b_test,3)
    val o_res = everyNth(a_test , 0)

    if(o_res.isEmpty()){
       println("O TEST GOOD")
    }
    else{
       println("O TEST FAIL")
    }

    if(a_res == listOf(3,6,9,12)){
       println("A TEST GOOD")
    }
    else{
       println("A TEST FAIL")
    }

    if(b_res == listOf("c","f","i","l")){
       println("B TEST GOOD")
    }
    else{
       println("B TEST FAIL")
    }
}
